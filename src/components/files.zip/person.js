import React, {Component} from 'react';
class TeamMembers extends Component {
    constructor(props){
        super(props);
        this.state={
            name:'',
            sex:'',
            age:'',
            hometown:'',
            school:'',
            major:'',
            hobbies:'',
        };
    }

    componentWillUnmount() {
        this.firebaseRef.off();
    }

    pushToFirebase(event) {
        const {name, sex, age, hometown, school, major, hobbies} = this.state;
        event.preventDefault();
        this.firebaseRef.child(name).set({name, sex, age, hometown, school, major, hobbies });
        this.setState({name: '', sex: '', age: '', hometown: '',school: '', major: '', hobbies: ''});
    }

    render(){
        return(
            <div>
                <label>Name</label>
                <input
                    value = { this.state.name }
                    onChange= {e => this.setState({name: e.target.value})}/>
                <br />
                <label>Age</label>
                <input
                    value = { this.state.age }
                    onChange= {e => this.setState({age: e.target.value})} />
                <br />
                <button onClick={this.pushToFirebase.bind(this)}>Submit</button>
            </div>
        );
    }
}


export default Person;